# 适配测试记录

执行日期：2026-10-27（Asia/Shanghai）。
基线：LRP-IVC/STSBench `38c5174d793f369b456ba27192b8384261562c0a`。

## 实际结果

- **27 passed**，全套耗时 **81.43 秒**，无失败/跳过。
- Ruff：修改链路的 `E9,F63,F7,F82` 检查通过；所有新增 Python 文件的默认规则检查通过。
- Python compileall 和 `git diff --check` 通过。
- 18 条 warning 来自原依赖 Matplotlib 3.5.3 与新版 pyparsing 的弃用接口，不是测试失败。
- 原挖掘核心 `annotator/mining/ego.py`、规则/负候选表 `annotator/mining/consts.py` 与基线无差异。
  `maneuvers.py` 仅增加 `TYPE_CHECKING` 导入，36 个枚举名、值及运行时代码不变。

测试环境：Windows x64，CPython 3.10.22，nuScenes-devkit 1.1.11，NumPy 1.26.4，
SQLAlchemy 2.0.40，Shapely 1.8.5.post1，Matplotlib 3.5.3，SciPy 1.13.1，
pytest 8.4.2，Ruff 0.14.2。精确的测试环境包列表另见 `requirements-tested-lock.txt`。

## 验证内容

| 检查 | 实际证据 |
|---|---|
| 官方划分 | 使用真实 devkit 名单核验 700 train / 150 val，无交集，并集等于 trainval；mini 使用 8/2 场景 |
| 默认 Val 与新增 split | 提取入口测试默认 val、train、trainval，模拟 mini 分别导出 16/64/80 帧 |
| sample 链与末帧 | 覆盖单帧、两帧、完整末帧、环、错误 prev、跨 scene、时间倒序/相等、错误末 token、计数不符 |
| ORM 时间顺序 | 逆序插入帧/agent 后重新从 DB 读取，按 timestamp 得到正确同步序列 |
| 速度 | 短序列安全；正常长度与上游二次外推计算逐值相同 |
| 原挖掘主体路径 | ego 单体、ego→agent、agent 单体、agent→agent、agent→ego 均执行；跟车、行人横穿、同行等命中断言通过 |
| 精确多标签映射 | 重叠事件合并正标签、半开窗口包含最终成员、非连续关联不补中间帧、空标签样本保留、负候选不混入正标签 |
| 真实 devkit 端到端 | 生成 10 场景/80 关键帧的模拟 JSON 和四张矩形向量地图；真实 NuScenes、NuScenesMap 读取，无 monkeypatch，独立进程运行提取→挖掘→导出 |
| 不依赖传感器内容 | 端到端夹具没有 samples/ 和 sweeps/ 目录；真实 devkit 链路通过；原始模拟 JSON/地图的运行前后 SHA-256 一致 |
| CLI 和 PKL | 独立进程挖掘、导出、校验模拟 info PKL；匹配率 100%，mini_train/mini_val 无交集；NumPy 数组载荷可读取 |
| 错误与覆盖保护 | 重复挖掘、已有 DB/JSON/PKL 输出、未完成状态被拒绝；PKL SHA-256 前后相同 |
| 对齐异常 | 缺 token、冲突 token 字段、重复 token、缺少标签行、错误 split、时间戳不符、子集与全量模式、重复 JSON 键均覆盖 |
| 旧 Val 回归 | 只读使用官方仓库自带数据库的 scene-0003、scene-0012、scene-0013；与 git 中原版 miner 的五种事件封装路径对照，正/负标签、关联帧、交互对象、主体信息一致 |

旧 Val DB 实际包含 150 场景、5,869 帧、7,888 轨迹、4,790 已有事件。
5,869 比完整 Val 的 6,019 少 150，与每场景遗漏一个末帧的源码问题一致。
原 DB Git blob 在操作前后保持 `b59ef308c8b7a48a72641ca5ffe854d136b49641`。
旧数据回归只证明相同已有帧输入下的事件封装等价；补回末帧后的全量事件数量应允许改变。

## 复现

安装依赖后，在仓库根目录运行：

```bash
python -m pytest -q --disable-warnings --junitxml=outputs/tests/junit.xml
python -m ruff check --select E9,F63,F7,F82 nuscenes_extractor.py mine_maneuvers.py \
  export_sample_labels.py validate_pkl_alignment.py annotator tests
python -m ruff check export_sample_labels.py validate_pkl_alignment.py annotator/data/pipeline.py tests
python -m compileall -q nuscenes_extractor.py mine_maneuvers.py \
  export_sample_labels.py validate_pkl_alignment.py annotator tests
```

交付 ZIP 是源码包，不包含 `.git`、原仓库的 45 MB 数据库或本机虚拟环境。
因此仅从 ZIP 解压运行时，旧 Val 回归项会明确 skip，其他 **26 项**可独立运行。
在保留官方 Git 历史和原 `nuScenes.db` 的克隆目录中可运行全部 27 项。
本地 JUnit 明细保存在 `outputs/tests/junit.xml`。

## 尚未验证

没有访问公司 nuScenes、CAN bus 或任何真实 DiffusionDrive PKL，没有生成全量标签。
没有下载或执行官方真实 mini 数据集；真实 devkit 测试使用的是合成元数据和合成几何地图。
没有在 Linux 服务器执行安装/运行，没有测量 850 场景全量挖掘的时间、峰值内存或自动标签精度。

内网需按 `TRAINVAL_DEPLOY.md` 运行并验收：真实官方地图兼容性，850 场景/34,149 帧完整性，
各 PKL 的匹配率和 train/val 隔离，标签覆盖率与各类数量，少量事件的人工检查，以及服务器资源开销。

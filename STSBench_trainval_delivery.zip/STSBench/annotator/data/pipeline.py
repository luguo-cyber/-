"""nuScenes identity/provenance tables; the original STSBench schema is unchanged."""

import json
from pathlib import Path
import sqlite3

from sqlalchemy import ForeignKey, create_engine, inspect, select
from sqlalchemy.orm import Mapped, mapped_column

from . import Base


class SampleIdentity(Base):
    __tablename__ = "sample_identity"
    frame_id: Mapped[int] = mapped_column(ForeignKey("frame.id"), primary_key=True)
    sample_token: Mapped[str] = mapped_column(unique=True)
    split: Mapped[str]


class PipelineMetadata(Base):
    __tablename__ = "pipeline_metadata"
    key: Mapped[str] = mapped_column(primary_key=True)
    value: Mapped[str]


def open_database(path, *, readonly=False):
    """Open an existing file, never silently create a DB in the current directory."""
    path = Path(path).expanduser().resolve(strict=True)
    uri = path.as_uri() + ("?mode=ro" if readonly else "?mode=rw")
    return create_engine("sqlite://", creator=lambda: sqlite3.connect(uri, uri=True))


def new_database(path):
    path = Path(path).expanduser().resolve()
    if path.suffix.lower() not in (".db", ".sqlite", ".sqlite3"):
        raise ValueError("Database output must end in .db, .sqlite or .sqlite3")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch(exist_ok=False)  # Never delete or replace an existing file.
    return open_database(path)


def get_metadata(session):
    if not inspect(session.bind).has_table(PipelineMetadata.__tablename__):
        return {}
    return {
        r.key: json.loads(r.value) for r in session.scalars(select(PipelineMetadata))
    }


def set_metadata(session, **values):
    for key, value in values.items():
        session.merge(PipelineMetadata(key=key, value=json.dumps(value)))
    session.commit()


def official_scene_splits(version):
    from nuscenes.utils.splits import create_splits_scenes

    version = version.removeprefix("v1.0-")
    if version not in ("trainval", "mini"):
        raise ValueError("Only trainval and mini are supported; test is excluded")
    names = create_splits_scenes()
    prefix = "mini_" if version == "mini" else ""
    train, val = set(names[prefix + "train"]), set(names[prefix + "val"])
    if train & val:
        raise ValueError("Official train/val scene lists overlap")
    return {
        **dict.fromkeys(train, prefix + "train"),
        **dict.fromkeys(val, prefix + "val"),
    }


def select_scenes(nusc, version, split):
    if split not in ("train", "val", "trainval"):
        raise ValueError(f"Unsupported split: {split}")
    membership = official_scene_splits(version)
    prefix = "mini_" if version.removeprefix("v1.0-") == "mini" else ""
    selected = {
        name: part
        for name, part in membership.items()
        if split == "trainval" or part == prefix + split
    }
    available = [s["name"] for s in nusc.scene]
    if len(available) != len(set(available)):
        raise ValueError("Duplicate scene names in nuScenes metadata")
    missing = set(selected) - set(available)
    if missing:
        raise ValueError(
            f"Missing {len(missing)} official scenes, e.g. {sorted(missing)[:5]}"
        )
    return selected


def scene_samples(nusc, scene):
    """Validate the linked keyframe chain, including its final sample."""
    samples, seen = [], set()
    token, previous = scene["first_sample_token"], ""
    while token:
        if token in seen:
            raise ValueError(f"Sample cycle in {scene['name']}: {token}")
        seen.add(token)
        sample = nusc.get("sample", token)
        if sample["scene_token"] != scene["token"] or sample["prev"] != previous:
            raise ValueError(f"Broken sample chain in {scene['name']}: {token}")
        if samples and sample["timestamp"] <= samples[-1]["timestamp"]:
            raise ValueError(f"Non-increasing timestamps in {scene['name']}")
        samples.append(sample)
        previous, token = token, sample["next"]
    if (
        not samples
        or samples[-1]["token"] != scene["last_sample_token"]
        or len(samples) != scene["nbr_samples"]
    ):
        raise ValueError(f"Incomplete sample chain in {scene['name']}")
    return samples


def write_json_new(path, data):
    path = Path(path).expanduser().resolve()
    if path.suffix.lower() != ".json":
        raise ValueError("Output must be a new .json file")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")

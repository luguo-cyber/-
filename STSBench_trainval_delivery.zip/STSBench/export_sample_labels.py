"""Export original STSBench positive events as multi-label nuScenes samples."""

import argparse
from collections import Counter
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from annotator.data import agent_maneuver, frame_maneuver
from annotator.data.models import Agent, Frame, Scene, Track
from annotator.data.maneuvers import (
    Maneuver,
    ManeuverType,
    PositiveManeuver,
    NegativeManeuver,
)
from annotator.data.pipeline import (
    SampleIdentity,
    get_metadata,
    official_scene_splits,
    open_database,
    write_json_new,
)


def summarize(samples, events):
    sample_counts = Counter(
        label for row in samples.values() for label in row["labels"]
    )
    event_counts = Counter(
        label for event in events.values() for label in event["labels"]
    )
    labeled = sum(bool(row["labels"]) for row in samples.values())
    return {
        "sample_count": len(samples),
        "event_count": len(events),
        "labeled_sample_count": labeled,
        "unlabeled_sample_count": len(samples) - labeled,
        "label_coverage": labeled / len(samples) if samples else 0.0,
        "split_sample_counts": dict(
            sorted(Counter(r["split"] for r in samples.values()).items())
        ),
        "class_sample_counts": {m.name: sample_counts[m.name] for m in ManeuverType},
        "class_event_counts": {m.name: event_counts[m.name] for m in ManeuverType},
        "ego_class_sample_counts": {
            m.name: sum(m.name in r["ego_labels"] for r in samples.values())
            for m in ManeuverType
        },
        "agent_class_sample_counts": {
            m.name: sum(m.name in r["agent_labels"] for r in samples.values())
            for m in ManeuverType
        },
    }


def build_export(session, split="all", event_filter="all"):
    metadata = get_metadata(session)
    if (
        not metadata.get("extraction_complete")
        or metadata.get("mining_status") != "complete"
    ):
        raise ValueError(
            "Need a completely extracted and mined DB from the adapted pipeline"
        )
    membership = official_scene_splits(metadata["version"])
    if split not in ("all", "train", "val", "trainval"):
        raise ValueError(f"Unsupported split: {split}")
    if event_filter not in ("all", "in_use"):
        raise ValueError(f"Unsupported event filter: {event_filter}")
    prefix = "mini_" if metadata["version"] == "v1.0-mini" else ""
    identities = {r.frame_id: r for r in session.scalars(select(SampleIdentity))}
    samples, frame_tokens = {}, {}
    rows = session.execute(
        select(Frame.id, Frame.timestamp, Scene.scene_token, Scene.name)
        .join(Scene)
        .order_by(Scene.name, Frame.timestamp)
    )
    for frame_id, timestamp, scene_token, scene_name in rows:
        identity = identities.get(frame_id)
        if identity is None or not identity.sample_token:
            raise ValueError(f"Missing sample identity for frame {frame_id}")
        if membership.get(scene_name) != identity.split:
            raise ValueError(f"Official split mismatch for scene {scene_name}")
        token = identity.sample_token
        if token in samples:
            raise ValueError(f"Duplicate sample_token: {token}")
        frame_tokens[frame_id] = token
        samples[token] = {
            "scene_token": scene_token,
            "scene_name": scene_name,
            "timestamp": timestamp,
            "split": identity.split,
            "labels": [],
            "ego_labels": [],
            "agent_labels": [],
            "event_ids": [],
        }
    if len(identities) != len(frame_tokens) or not samples:
        raise ValueError("Sample identity/frame count mismatch or empty DB")
    if set(metadata["scene_names"]) != {r["scene_name"] for r in samples.values()}:
        raise ValueError("Extracted scene inventory does not match provenance")
    if "scene_sample_counts" in metadata and metadata["scene_sample_counts"] != dict(
        Counter(row["scene_name"] for row in samples.values())
    ):
        raise ValueError("Scene sample counts differ from original nuScenes metadata")

    categories = dict(
        session.execute(
            select(Track.instance_token, Agent.category_name).join(Agent).distinct()
        ).all()
    )
    events = {}
    for row in session.execute(
        select(
            Maneuver.id,
            Maneuver.is_ego,
            Maneuver.is_agent,
            Maneuver.instance_token,
            Maneuver.in_use,
            Maneuver.manually_labeled,
        )
    ):
        if bool(row.is_ego) == bool(row.is_agent):
            raise ValueError(f"Invalid actor flags for event {row.id}")
        events[row.id] = {
            "labels": [],
            "negative_candidates": [],
            "actor": "ego" if row.is_ego else "agent",
            "instance_token": row.instance_token,
            "category_name": "ego"
            if row.is_ego
            else categories.get(row.instance_token),
            "other_instance_tokens": [],
            "sample_tokens": [],
            "in_use": row.in_use,
            "manually_labeled": row.manually_labeled,
        }
    for table, field in (
        (PositiveManeuver, "labels"),
        (NegativeManeuver, "negative_candidates"),
    ):
        for event_id, label in session.execute(select(table.maneuver_id, table.type)):
            # Original UI can leave unassociated negative rows; they are not events.
            if event_id is not None:
                events[event_id][field].append(label.name)
    for event_id, frame_id in session.execute(
        select(frame_maneuver.c.maneuver, frame_maneuver.c.frame_id)
        .join(Frame, Frame.id == frame_maneuver.c.frame_id)
        .order_by(Frame.timestamp)
    ):
        events[event_id]["sample_tokens"].append(frame_tokens[frame_id])
    for event_id, instance_token in session.execute(
        select(agent_maneuver.c.maneuver, Track.instance_token)
        .join(Agent, Agent.id == agent_maneuver.c.agent_id)
        .join(Track, Track.id == Agent.track_id)
        .distinct()
    ):
        events[event_id]["other_instance_tokens"].append(instance_token)

    selected = {
        token: row
        for token, row in samples.items()
        if split in ("all", "trainval") or row["split"] == prefix + split
    }
    if not selected:
        raise ValueError(f"No samples for requested split {split}")
    if split == "trainval" and {r["split"] for r in selected.values()} != {
        prefix + "train",
        prefix + "val",
    }:
        raise ValueError(
            "Requested trainval but DB does not contain both official splits"
        )
    output_events = {}
    for event_id, event in events.items():
        tokens = event["sample_tokens"]
        if not tokens or len({samples[t]["scene_token"] for t in tokens}) != 1:
            raise ValueError(f"Empty or cross-scene event: {event_id}")
        if tokens[0] not in selected or (
            event_filter == "in_use" and not event["in_use"]
        ):
            continue
        for field in ("labels", "negative_candidates", "other_instance_tokens"):
            event[field] = sorted(set(event[field]))
        event["start_timestamp"] = samples[tokens[0]]["timestamp"]
        event["end_timestamp"] = samples[tokens[-1]]["timestamp"]
        output_events[str(event_id)] = event
        for token in tokens:
            row = selected[token]
            row["labels"].extend(event["labels"])
            row[event["actor"] + "_labels"].extend(event["labels"])
            row["event_ids"].append(str(event_id))
    for row in selected.values():
        for field in ("labels", "ego_labels", "agent_labels"):
            row[field] = sorted(set(row[field]))
    return {
        "schema_version": 1,
        "metadata": {
            **metadata,
            "export_split": split,
            "event_filter": event_filter,
            "mapping": "exact frame_maneuver membership; no temporal expansion",
            "label_source": "positive_maneuver; negatives are QA candidates only",
        },
        "taxonomy": {m.name: m.value for m in ManeuverType},
        "summary": summarize(selected, output_events),
        "samples": selected,
        "events": output_events,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db_path", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--split", choices=("all", "train", "val", "trainval"), default="all"
    )
    parser.add_argument("--event-filter", choices=("all", "in_use"), default="all")
    args = parser.parse_args()
    if args.output.exists():
        parser.error(f"Refusing to overwrite existing output: {args.output}")
    engine = open_database(args.db_path, readonly=True)
    try:
        with Session(engine) as session:
            result = build_export(session, args.split, args.event_filter)
        write_json_new(args.output, result)
        print(result["summary"])
    finally:
        engine.dispose()


if __name__ == "__main__":
    main()

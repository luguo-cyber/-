# STSBench → nuScenes Trainval 部署说明

本适配基于官方仓库提交 `38c5174d793f369b456ba27192b8384261562c0a`。
用途是导出原始自动挖掘事件与关键帧的多标签对应关系，供后续训练数据划分使用。
未修改 DiffusionDrive、未实现 MoS，也不需要读取公司的原始 PKL 来生成标签。

## 1. 环境与数据

推荐独立的 **Python 3.10** 环境。避免直接使用仓库原来的大而全的 requirements；
本流程不需要 rerun、fpsample、Torch、MMCV、CAN bus 或 VLM 推理服务。

```bash
cd /path/to/STSBench
python3.10 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-trainval.txt
```

`requirements-tested-lock.txt` 记录本次实际通过测试的完整依赖版本（含测试工具）；
需要固定传递依赖时可改为安装该文件。Linux 安装与完整数据运行仍需内网验收。

离线部署：在与内网服务器相同的操作系统、CPU 架构和 Python 3.10 环境上准备 wheelhouse，
不要把 Windows 测试环境的二进制依赖直接带到 Linux。

```bash
python -m pip download -r requirements-test.txt -d wheelhouse
# 内网执行：
python -m pip install --no-index --find-links wheelhouse -r requirements-test.txt
```

`--dataroot` 是 **nuScenes devkit 的根目录**：它下面应有 `v1.0-trainval/scene.json` 等元数据、
`maps/expansion/*.json`，以及通常的 `samples/`、`sweeps/`。
目录本身叫什么不重要；不能误把只存放 JSON 的版本目录当作 dataroot。

```text
/data/nuscenes/
  v1.0-trainval/     scene.json, sample.json, sample_data.json, ego_pose.json, ...
  maps/             官方地图文件及 expansion/ 四个地点的向量地图 JSON
  samples/          关键帧传感器文件（本挖掘流程不读取二进制内容）
  sweeps/           本流程不读取、不检查、不修复
```

提取使用关键帧传感器元数据、LIDAR_TOP 的 ego_pose、sample_annotation 和向量地图。
不读取图片、点云、历史 sweeps 或 CAN bus，因此已有的 5.4% sweeps 文件缺失不影响本流程。
如果缺的是 JSON 元数据、关键帧的关联记录或地图，则需要先修复数据，脚本不会静默跳过。
不支持 Test。

## 2. 生成标签

使用独立的**新输出目录**。以下示例不会修改或覆盖原始数据、现有 PKL 或仓库自带的 `nuScenes.db`。
所有提取/导出/报告输出均拒绝覆盖已有文件；不提供 `--overwrite`。

```bash
OUT=/work/stsbench_outputs/run_001
mkdir -p "$OUT"

python nuscenes_extractor.py \
  --dataroot /data/nuscenes --version trainval --split trainval \
  --db_path "$OUT/trainval.db"

python mine_maneuvers.py --db_path "$OUT/trainval.db"

python export_sample_labels.py \
  --db_path "$OUT/trainval.db" --split trainval \
  --output "$OUT/labels_trainval.json"
```

可以分别提取 `--split train` 或 `--split val`。默认仍是 `--version trainval --split val`。
官方 devkit 的 `train`/`val` 场景名单用于选择场景，`trainval` 是两者并集；不是随机分组，
也不是使用所有 scene 不加区分。缺少任何所选官方场景会报错。
完整 Trainval 应有 700 个 train 场景、150 个 val 场景；按公司提供的数据清单，
应核验 28,130 个 train 关键帧、6,019 个 val 关键帧，合计 34,149。

同一个 Trainval DB 也可以单独导出 train/val，而不必再次挖掘：

```bash
python export_sample_labels.py --db_path "$OUT/trainval.db" --split train --output "$OUT/labels_train.json"
python export_sample_labels.py --db_path "$OUT/trainval.db" --split val --output "$OUT/labels_val.json"
```

小规模真实数据验证可用官方 mini：`--version mini --split train|val|trainval`，实际对应
`mini_train`（8 场景）/`mini_val`（2 场景）/两者并集。输出保留 `mini_` 前缀，避免与正式集混淆。

**不要在训练标签流程中运行 `downsample_maneuvers.py`。** 它用于构造平衡的 VQA benchmark，
会筛选事件。本导出器默认 `--event-filter all` 保留全部原始事件；如确实要使用人工/下采样结果，
可显式用 `--event-filter in_use`。事件记录保留 `in_use`、`manually_labeled`。

提取和挖掘会记录完成状态。中断或失败后，保留故障 DB 供排查，在新路径从提取重新运行。
本版本不支持断点续跑；重复运行挖掘会拒绝，以免事件重复累加。不要并发写同一个 DB。
交互挖掘沿用上游的场景内轨迹两两比较，Trainval 的耗时和内存需在公司服务器测量。

## 3. JSON 格式与标签语义

输出顶层包含 `metadata`、`taxonomy`、`summary`、`samples`、`events`。
`samples` 以真正的 **nuScenes sample_token** 为键：

```json
{
  "samples": {
    "<sample_token>": {
      "scene_token": "<scene_token>",
      "scene_name": "scene-0001",
      "timestamp": 1532402927647951,
      "split": "train",
      "labels": ["ACCELERATE", "FOLLOW_AGENT"],
      "ego_labels": ["ACCELERATE", "FOLLOW_AGENT"],
      "agent_labels": [],
      "event_ids": ["12", "19"]
    }
  }
}
```

- `labels` 是该帧所有主体的正向行为标签并集，去重但不互斥；训练侧需要 ego 专属语义时读 `ego_labels`。
- `events[event_id]` 保留原枚举名、主体 `ego/agent`、`instance_token`、`category_name`、
  交互对象 `other_instance_tokens`，以及事件实际关联的有序 `sample_tokens`。
  对 agent→ego 事件，目标语义由原来的 `*_EGO` 枚举表达，`other_instance_tokens` 为空。
- 对每个事件，原算法返回 `[start_idx, end_idx)`，导出只使用 `frame_maneuver` 中实际关联的帧。
  不把事件扩大到整个 scene，不插值补齐轨迹中未关联的帧，不通过相近时间戳猜 token。
- 没有检测到事件的样本仍存在，标签列表为空；空列表表示“原挖掘器未命中”，并非“直行”或负例。
- `negative_candidates` 保留原问答负候选，仅供追溯，**不是训练样本已发生的行为标签，也不是可靠的逐帧负标签**。
- `taxonomy` 直接来自 `ManeuverType` 的 36 个枚举，名称和值不变；类别计数包含零样本类别。
  论文场景数与枚举数量不是同一个统计口径，本适配不人为补出新类别。
- `summary.class_event_counts` 按事件计数；`class_sample_counts` 按去重 sample_token 计数。
  多标签会使各类计数之和超过样本总数。覆盖率的分母是导出的全部样本。

## 4. 只读校验 DiffusionDrive PKL

支持常见 `{"infos": [...]}`、直接 info 列表、`{"data_list": [...]}`；token 字段支持 `token` 或
`sample_token`。同时存在两种字段时必须相同。保留原 PKL 的顺序，不重写内容。
只加载公司自己生成的可信 PKL；pickle 是 Python 序列化格式，读取时可能导入其依赖类。
NumPy 数组可直接读取；如 PKL 包含 MMCV 等自定义对象，应在具有对应依赖的环境运行该校验脚本。
校验脚本本身只使用标准库，不导入 STSBench/nuScenes/Torch。

```bash
python validate_pkl_alignment.py \
  --labels "$OUT/labels_trainval.json" \
  --pkl train=/data/infos/nuscenes_infos_train.pkl \
  --pkl val=/data/infos/nuscenes_infos_val.pkl \
  --pkl train=/data/infos/nuscenes_infos_train_ori.pkl \
  --pkl val=/data/infos/nuscenes_infos_val_6019.pkl \
  --output "$OUT/alignment.json"
```

调试小样本也用所属的官方 split，不根据文件名推断：

```bash
python validate_pkl_alignment.py --labels "$OUT/labels_trainval.json" \
  --pkl train=/data/infos/debug_train.pkl --output "$OUT/debug_alignment.json"
```

报告包含：

- `sample_match_rate`：成功匹配的 PKL 行数 / PKL 总行数，缺 token 行也计入分母。
- `unique_sample_match_rate`：匹配的唯一 token 数 / PKL 唯一有效 token 数。
- `label_coverage_among_matched_samples`：有正标签的匹配 token 数 / 匹配 token 数。
- `label_coverage_among_pkl_unique_samples`：有正标签的匹配 token 数 / PKL 唯一有效 token 数。
- ego/agent/全部标签的逐类唯一样本数量；重复、缺失、错误 split、时间戳/scene_token 不一致记录。
- 每两份 PKL 的 token 交集；同 split 的主文件与备份重叠正常，声明不相交 split 的重叠判为错误。

正常返回 **0**；不匹配、重复、错误 split、元数据不一致或空 PKL 返回 **2**，并保留报告。
文件无法读取或结构不支持时异常退出，不生成成功报告。
训练预处理可能过滤末尾帧/不可用样本，所以默认允许 PKL 是标签全集的子集；
标签存在但不在 PKL 的样本单独统计，不直接算错误。确认要验证完整 split 时增加 `--require-full-split`。
它检查“PKL 覆盖所提供标签文件的该 split”；完整官方数据的场景数与关键帧数仍须按第 2 节核验。
**样本匹配率应达到 100%；事件覆盖率不要求达到 100%。**

## 5. 修改边界与源码审查

已完整检查提取/挖掘链路及其直接依赖：`nuscenes_extractor.py`、`mine_maneuvers.py`、
`annotator/mining/ego.py`、`annotator/mining/consts.py`、`annotator/data/{__init__,models,maneuvers,utils}.py`，
并检查了下采样和 VQA 使用标签的方式。修改限于本任务的数据链路。

| 问题 | 处理 |
|---|---|
| 提取器只接受 val | 增加官方 train/val/trainval，修正 mini 的 split 对应 |
| 原循环进入末帧前就退出 | 按 sample.next 完整遍历；验证 prev、scene、时间递增、首尾和计数 |
| 原 `db_path.name` 丢失目录 | 提取/挖掘/新工具统一按完整路径打开；不存在的输入 DB 不会被自动创建 |
| 原提取器无条件删除已有 DB | 改为独占新建，拒绝覆盖 |
| 无 sample_token，且 `Agent.sample_token` 实为 sample_annotation token | 新增 `sample_identity` 表，按 frame_id 保存真正的 sample_token 和 split；不改旧列语义 |
| ORM 关系没有明确时间排序 | Scene.frames 和 Track.agents 按帧时间排序，挖掘保持原顺序约定 |
| 极短序列速度外推失败 | 0/1/2/3 帧安全处理；4 帧及以上保持原二次多项式外推 |
| 重跑累加事件、中断后无法辨认 | 元数据记录状态；主挖掘命令拒绝重复/不完整输入；导出只接受完整结果 |

`annotator/mining/ego.py`、`annotator/mining/consts.py` 保持原样；`annotator/data/maneuvers.py`
只补充 `TYPE_CHECKING` 导入以通过静态检查，运行时行为不变。保留的规则
包括默认 6 帧窗口、连续命中合并、速度/角度/距离/地图判断、负候选和类型枚举。
原脚本 agent 单体列表没有启用 `DECELERATE`，本适配保留；不把补充算法混入适配。
同步轨迹仍沿用原来的共同观测帧规则，可能存在观测间隔；不另设时间间隔阈值。
恢复末帧会合理地改变 Val 末尾附近的窗口/速度外推和事件总数，不能声称与旧漏帧结果逐项相同。

附加表不改变旧 DB 的 Frame/Scene 列，因此旧 Val DB 仍可由原有 ORM 读取。
**仓库自带的旧 `nuScenes.db` 不能直接导出完整训练标签**：它没有 sample_token 附加表且原流程漏末帧，
请从元数据提取到新 DB。下采样、人工标注、VQA 脚本不属于本次部署链路，其历史路径问题未作无关改动。

## 6. 测试和验收

```bash
python -m pip install -r requirements-test.txt
python -m pytest -q
python -m ruff check --select E9,F63,F7,F82 nuscenes_extractor.py mine_maneuvers.py \
  export_sample_labels.py validate_pkl_alignment.py annotator tests
python -m compileall -q nuscenes_extractor.py mine_maneuvers.py \
  export_sample_labels.py validate_pkl_alignment.py annotator tests
```

实际执行记录及通过数量见 [TEST_REPORT.md](TEST_REPORT.md)。测试夹具会在临时目录写入模拟 DB/PKL，
不访问公司数据；模拟 NuScenes/地图 API 与真实 devkit 数据验证的边界在测试报告中明确列出。

内网必须完成的验收：官方 850 场景/34,149 样本计数及 train/val 分别计数；真实地图提取和全量挖掘；
主 PKL、备份 PKL、调试 PKL 的对应率与拆分正确性；各类分布和部分事件的人工抽查；实际运行资源消耗。
自动挖掘结果尚未经论文流程的人工验证，应作为继承原 STSBench 启发式的训练分域候选标签。

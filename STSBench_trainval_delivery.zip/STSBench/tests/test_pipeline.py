import hashlib
import json
from pathlib import Path
import pickle
import subprocess
import sys
from types import SimpleNamespace

import numpy as np
import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

import nuscenes_extractor as extractor
from annotator.data import Base
from annotator.data.models import Agent, Ego, Frame, Scene, Track, VisibilityType
from annotator.data.maneuvers import (
    Maneuver,
    ManeuverType,
    PositiveManeuver,
    NegativeManeuver,
)
from annotator.data.pipeline import (
    SampleIdentity,
    get_metadata,
    new_database,
    official_scene_splits,
    open_database,
    scene_samples,
    select_scenes,
    set_metadata,
)
from annotator.data.utils import compute_vel
from export_sample_labels import build_export
from mine_maneuvers import mine_agent_session, mine_ego_session, mine_ego_maneuver
from tests.synthetic_nuscenes import (
    SyntheticMap,
    SyntheticNuScenes,
    write_devkit_fixture,
)
from validate_pkl_alignment import load_infos, load_labels, validate_infos

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("split, count", [(None, 16), ("train", 64), ("trainval", 80)])
def test_extractor_entrypoint_default_val_and_splits(
    tmp_path, monkeypatch, split, count
):
    path = tmp_path / "nested" / "extracted.db"
    args = ["nuscenes_extractor.py", "--version", "mini", "--db_path", str(path)]
    if split:
        args.extend(["--split", split])
    monkeypatch.setattr(sys, "argv", args)
    monkeypatch.setattr(extractor, "NuScenes", SyntheticNuScenes)
    monkeypatch.setattr(extractor, "NuScenesMap", SyntheticMap)
    extractor.main()
    with Session(open_database(path, readonly=True)) as session:
        assert len(session.scalars(select(SampleIdentity)).all()) == count
        assert get_metadata(session)["split"] == (split or "val")


@pytest.fixture
def extracted_db(tmp_path):
    nusc = SyntheticNuScenes()
    path = tmp_path / "nested directory" / "nuScenes.db"
    engine = new_database(path)
    Base.metadata.create_all(engine)
    with Session(engine) as session:
        selected = select_scenes(nusc, "mini", "trainval")
        set_metadata(
            session,
            version="v1.0-mini",
            split="trainval",
            scene_names=sorted(selected),
            extraction_complete=False,
            mining_status="not_started",
        )
        extractor.map_extractor(SyntheticMap, session)
        extractor.scene_extractor(nusc, SyntheticMap, selected, session, selected)
        extractor.compute_ego_vel(session)
        set_metadata(session, extraction_complete=True)
    engine.dispose()
    return path


def test_official_splits():
    membership = official_scene_splits("trainval")
    assert sum(x == "train" for x in membership.values()) == 700
    assert sum(x == "val" for x in membership.values()) == 150
    nusc = SimpleNamespace(scene=[{"name": name} for name in membership])
    train = select_scenes(nusc, "trainval", "train")
    val = select_scenes(nusc, "trainval", "val")
    assert not (train.keys() & val.keys())
    assert (
        train.keys() | val.keys() == select_scenes(nusc, "trainval", "trainval").keys()
    )
    assert set(select_scenes(SyntheticNuScenes(), "mini", "val").values()) == {
        "mini_val"
    }
    with pytest.raises(ValueError, match="Missing"):
        select_scenes(SimpleNamespace(scene=[]), "trainval", "val")
    with pytest.raises(ValueError, match="test"):
        official_scene_splits("test")


def test_sample_chain_last_and_singleton():
    for size in (1, 2, 8):
        nusc = SyntheticNuScenes(frame_count=size)
        chain = scene_samples(nusc, nusc.scene[0])
        assert len(chain) == size
        assert chain[-1]["token"] == nusc.scene[0]["last_sample_token"]


@pytest.mark.parametrize("failure", ["cycle", "prev", "scene", "time", "last", "count"])
def test_bad_sample_chain(failure):
    nusc = SyntheticNuScenes()
    scene = nusc.scene[0]
    first = nusc.get("sample", scene["first_sample_token"])
    second = nusc.get("sample", first["next"])
    if failure == "cycle":
        second["next"] = first["token"]
    elif failure == "prev":
        second["prev"] = "bad"
    elif failure == "scene":
        second["scene_token"] = "bad"
    elif failure == "time":
        second["timestamp"] = first["timestamp"]
    elif failure == "last":
        scene["last_sample_token"] = first["token"]
    else:
        scene["nbr_samples"] += 1
    with pytest.raises(ValueError):
        scene_samples(nusc, scene)


def test_extraction_final_frames_identity_and_paths(extracted_db):
    with Session(open_database(extracted_db, readonly=True)) as session:
        frames = session.scalars(select(Frame)).all()
        identities = session.scalars(select(SampleIdentity)).all()
        assert len(frames) == len(identities) == 80
        assert sum(row.sample_token.endswith("-7") for row in identities) == 10
        assert all(row.ego.velocity == pytest.approx(4.0) for row in frames)
        assert all("annotation" not in row.sample_token for row in identities)
        assert get_metadata(session)["extraction_complete"]
    with pytest.raises(FileExistsError):
        new_database(extracted_db)
    with pytest.raises(FileNotFoundError):
        open_database(extracted_db.parent / "missing.db")


def test_velocity_small_sequences_and_original_polynomial():
    objs = [
        SimpleNamespace(x=i * i, y=0.0, frame=SimpleNamespace(timestamp=i * 500_000))
        for i in range(8)
    ]
    for count in range(9):
        assert len(compute_vel(objs[:count])) == count
    vel = np.linalg.norm(np.diff([[o.x, o.y] for o in objs], axis=0), axis=1) / 0.5
    expected = np.append(
        vel, np.poly1d(np.polyfit(np.arange(len(vel)), vel, 2))(len(vel))
    )
    np.testing.assert_array_equal(compute_vel(objs), expected)
    objs[1].frame.timestamp = objs[0].frame.timestamp
    with pytest.raises(ValueError, match="strictly"):
        compute_vel(objs)


def test_temporal_order_is_not_insertion_order(tmp_path):
    engine = new_database(tmp_path / "order.db")
    Base.metadata.create_all(engine)
    with Session(engine) as session:
        scene = Scene(scene_token="scene", name="scene-0061", location="boston-seaport")
        track = Track(instance_token="track", scene=scene)
        for i in (2, 0, 1):
            frame = Frame(timestamp=i * 500_000, scene=scene)
            pose = dict(x=float(i), y=0.0, z=0.0, qw=1.0, qx=0.0, qy=0.0, qz=0.0)
            agent = Agent(
                sample_token=f"annotation{i}",
                frame=frame,
                track=track,
                category_name="vehicle.car",
                width=1.0,
                length=2.0,
                height=1.0,
                vx=2.0,
                vy=0.0,
                vz=0.0,
                visibility=VisibilityType.FULLY_VISIBLE,
                **pose,
            )
            session.add_all(
                [
                    agent,
                    Ego(frame=frame, ego_pose_token=f"ego{i}", velocity=2.0, **pose),
                ]
            )
        session.commit()
        session.expire_all()
        assert [f.timestamp for f in scene.frames] == [0, 500_000, 1_000_000]
        assert [a.frame.timestamp for a in track.agents] == [0, 500_000, 1_000_000]
        agents, egos = track.get_synchronized_ego()
        assert [a.frame.timestamp for a in agents] == [e.frame.timestamp for e in egos]
    engine.dispose()


def test_exact_multilabel_membership_and_empty_samples(extracted_db):
    with Session(open_database(extracted_db)) as session:
        scene = session.scalars(select(Scene).order_by(Scene.name)).first()
        frames = scene.frames
        # Non-contiguous membership must not fill in the intervening frame.
        for label, members in (
            (ManeuverType.LEFT_TURN, [frames[0], frames[2]]),
            (ManeuverType.ACCELERATE, [frames[2], frames[-1]]),
        ):
            session.add(
                Maneuver(
                    frames=members,
                    is_ego=True,
                    is_agent=False,
                    in_use=True,
                    manually_labeled=False,
                    labeling_time=-1,
                    pos_maneuvers=[PositiveManeuver(type=label)],
                    neg_maneuvers=[NegativeManeuver(type=ManeuverType.STOP)],
                    prelabeled_pos_maneuvers=[label],
                    prelabeled_neg_maneuvers=[ManeuverType.STOP],
                )
            )
        set_metadata(session, mining_status="complete")
        data = build_export(session)
        prefix = scene.name
        assert data["samples"][prefix + "-2"]["labels"] == ["ACCELERATE", "LEFT_TURN"]
        assert data["samples"][prefix + "-1"]["labels"] == []
        assert data["samples"][prefix + "-7"]["labels"] == ["ACCELERATE"]
        assert data["summary"]["class_sample_counts"]["STOP"] == 0
        assert data["summary"]["class_event_counts"]["ACCELERATE"] == 1
        assert len(data["samples"]) == 80
        assert len(build_export(session, "val")["samples"]) == 16
        assert len(build_export(session, "train")["samples"]) == 64


def test_original_mining_functions_run_all_actor_paths(extracted_db):
    with Session(open_database(extracted_db)) as session:
        mine_ego_session(session)
        mine_agent_session(session)
        set_metadata(session, mining_status="complete")
        data = build_export(session)
        assert data["summary"]["class_event_counts"]["FOLLOW_AGENT"] > 0
        assert data["summary"]["class_event_counts"]["LEAD_EGO"] > 0
        assert data["summary"]["class_event_counts"]["CROSS"] > 0
        assert data["summary"]["class_event_counts"]["WALK_ALONGSIDE"] > 0
        assert data["summary"]["unlabeled_sample_count"] > 0
        events = list(data["events"].values())
        assert any(e["actor"] == "ego" and e["other_instance_tokens"] for e in events)
        assert any(e["actor"] == "agent" and e["other_instance_tokens"] for e in events)


def test_half_open_window_includes_last_frame():
    frames = [Frame(timestamp=i * 500_000) for i in range(7)]
    for frame, speed in zip(frames, [0.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0]):
        frame.ego = Ego(velocity=speed)
    events = list(mine_ego_maneuver(frames, ManeuverType.ACCELERATE))
    assert len(events) == 1
    assert events[0].frames == frames[1:7]


def run_cli(script, *args, expected=0):
    result = subprocess.run(
        [sys.executable, str(ROOT / script), *map(str, args)],
        capture_output=True,
        text=True,
        cwd=ROOT,
    )
    assert result.returncode == expected, result.stdout + result.stderr
    return result


def test_cli_mining_export_alignment_and_no_overwrite(extracted_db, tmp_path):
    run_cli("mine_maneuvers.py", "--db_path", extracted_db)
    run_cli("mine_maneuvers.py", "--db_path", extracted_db, expected=2)
    labels = tmp_path / "labels.json"
    run_cli("export_sample_labels.py", "--db_path", extracted_db, "--output", labels)
    data = json.loads(labels.read_text())
    pkls = []
    for split in ("mini_train", "mini_val"):
        infos = [
            {
                "token": t,
                "timestamp": r["timestamp"],
                "scene_token": r["scene_token"],
                "unused_numpy_payload": np.ones(2),
            }
            for t, r in data["samples"].items()
            if r["split"] == split
        ]
        path = tmp_path / (split + ".pkl")
        path.write_bytes(
            pickle.dumps({"infos": infos, "metadata": {"version": "v1.0-mini"}})
        )
        pkls.append(path)
    before = [hashlib.sha256(p.read_bytes()).hexdigest() for p in pkls]
    report = tmp_path / "report.json"
    run_cli(
        "validate_pkl_alignment.py",
        "--labels",
        labels,
        "--pkl",
        f"mini_train={pkls[0]}",
        "--pkl",
        f"mini_val={pkls[1]}",
        "--output",
        report,
        "--require-full-split",
    )
    result = json.loads(report.read_text())
    assert result["ok"]
    assert all(r["sample_match_rate"] == 1.0 for r in result["files"])
    assert result["pairwise_overlaps"][0]["sample_overlap_count"] == 0
    assert before == [hashlib.sha256(p.read_bytes()).hexdigest() for p in pkls]
    run_cli(
        "export_sample_labels.py",
        "--db_path",
        extracted_db,
        "--output",
        labels,
        expected=2,
    )
    run_cli("nuscenes_extractor.py", "--db_path", extracted_db, expected=2)
    run_cli(
        "validate_pkl_alignment.py",
        "--labels",
        labels,
        "--pkl",
        f"mini_train={pkls[0]}",
        "--output",
        pkls[0],
        expected=2,
    )
    assert before == [hashlib.sha256(p.read_bytes()).hexdigest() for p in pkls]


def test_alignment_missing_duplicates_leakage_and_subsets():
    data = {
        "taxonomy": {"ACCELERATE": 0},
        "samples": {
            "a": {
                "split": "train",
                "timestamp": 1,
                "scene_token": "s1",
                "labels": ["ACCELERATE"],
                "ego_labels": ["ACCELERATE"],
                "agent_labels": [],
            },
            "b": {
                "split": "train",
                "timestamp": 2,
                "scene_token": "s1",
                "labels": [],
                "ego_labels": [],
                "agent_labels": [],
            },
            "v": {
                "split": "val",
                "timestamp": 3,
                "scene_token": "s2",
                "labels": [],
                "ego_labels": [],
                "agent_labels": [],
            },
        },
    }
    good, _ = validate_infos([{"sample_token": "a"}], data, "train")
    assert good["ok"] and good["sample_match_rate"] == 1
    assert good["expected_split_samples_absent_from_pkl_count"] == 1
    strict, _ = validate_infos([{"token": "a"}], data, "train", True)
    assert not strict["ok"]
    bad, _ = validate_infos(
        [
            {"token": "a"},
            {"token": "a", "timestamp": 2},
            {"token": "missing"},
            {"token": "v"},
            {},
            {"token": "a", "sample_token": "b"},
        ],
        data,
        "train",
    )
    assert bad["sample_match_rate"] == 0.5
    assert bad["class_sample_counts"] == {"ACCELERATE": 1}
    assert bad["official_split_mismatch_tokens"] == ["v"]
    assert bad["invalid_row_count"] == 2
    assert bad["metadata_mismatch_count"] == 1
    assert bad["missing_label_tokens"] == ["missing"]
    assert bad["duplicate_pkl_tokens"] == {"a": 2}


def test_real_devkit_full_cli_with_synthetic_json_and_vector_maps(tmp_path):
    dataroot = tmp_path / "data"
    write_devkit_fixture(dataroot)
    hashes = {
        p: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in dataroot.rglob("*")
        if p.is_file()
    }
    assert not (dataroot / "samples").exists()
    assert not (dataroot / "sweeps").exists()
    db, labels = tmp_path / "out" / "mini.db", tmp_path / "labels.json"
    run_cli(
        "nuscenes_extractor.py",
        "--dataroot",
        dataroot,
        "--version",
        "mini",
        "--split",
        "trainval",
        "--db_path",
        db,
    )
    run_cli("mine_maneuvers.py", "--db_path", db)
    run_cli(
        "export_sample_labels.py",
        "--db_path",
        db,
        "--split",
        "trainval",
        "--output",
        labels,
    )
    data = json.loads(labels.read_text())
    assert len(data["samples"]) == 80
    assert data["summary"]["split_sample_counts"] == {"mini_train": 64, "mini_val": 16}
    assert data["summary"]["class_event_counts"]["CROSS"] > 0
    assert data["summary"]["class_event_counts"]["FOLLOW_AGENT"] > 0
    for path, digest in hashes.items():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest


def test_incomplete_extraction_and_mining_are_rejected(extracted_db, tmp_path):
    with Session(open_database(extracted_db)) as session:
        with pytest.raises(ValueError, match="completely"):
            build_export(session)
        set_metadata(session, extraction_complete=False)
    run_cli("mine_maneuvers.py", "--db_path", extracted_db, expected=2)
    with Session(open_database(extracted_db)) as session:
        set_metadata(session, extraction_complete=True, mining_status="running")
    run_cli("mine_maneuvers.py", "--db_path", extracted_db, expected=2)


def test_export_checks_identities_and_official_membership(extracted_db):
    with Session(open_database(extracted_db)) as session:
        set_metadata(session, mining_status="complete")
        row = session.scalars(select(SampleIdentity)).first()
        original = row.split
        row.split = "mini_val" if row.split == "mini_train" else "mini_train"
        session.commit()
        with pytest.raises(ValueError, match="split mismatch"):
            build_export(session)
        row.split = original
        session.commit()
        session.delete(row)
        session.commit()
        with pytest.raises(ValueError, match="Missing sample identity"):
            build_export(session)


@pytest.mark.parametrize(
    "wrapper", [lambda x: x, lambda x: {"infos": x}, lambda x: {"data_list": x}]
)
def test_pkl_formats(tmp_path, wrapper):
    path = tmp_path / "infos.pkl"
    infos = [{"token": "a"}]
    path.write_bytes(pickle.dumps(wrapper(infos)))
    assert load_infos(path) == infos


def test_duplicate_json_keys_are_rejected(tmp_path):
    path = tmp_path / "labels.json"
    path.write_text('{"samples": {"a": {}, "a": {}}}', encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate JSON key"):
        load_labels(path)

"""Small deterministic nuScenes API fixture; no sensor files or sweeps exist."""

import json
from pathlib import Path
from types import SimpleNamespace

from annotator.data.models import SensorType
from annotator.data.pipeline import official_scene_splits


class SyntheticMap:
    def __init__(self, map_name, **kwargs):
        self.map_name = map_name
        for layer in ("lane", "ped_crossing", "drivable_area", "walkway"):
            setattr(self, layer, [{"token": f"{map_name}-{layer}"}])

    def layers_on_point(self, x, y, layers):
        return {
            layer: (
                f"{self.map_name}-{layer}" if layer != "ped_crossing" or y > 2 else ""
            )
            for layer in layers
        }


class SyntheticNuScenes:
    def __init__(
        self, version="v1.0-mini", dataroot=None, verbose=False, frame_count=8
    ):
        self.version = version
        self.tables = {
            name: {}
            for name in (
                "scene",
                "sample",
                "sample_data",
                "sample_annotation",
                "ego_pose",
                "calibrated_sensor",
                "log",
                "visibility",
            )
        }
        self.tables["log"]["log"] = {"location": "boston-seaport"}
        self.tables["visibility"]["4"] = {"level": "v80-100"}
        self.scene = []
        for name in sorted(official_scene_splits(version)):
            scene_token = name + "-scene"
            self.scene.append(
                {
                    "name": name,
                    "token": scene_token,
                    "log_token": "log",
                    "first_sample_token": f"{name}-0",
                    "last_sample_token": f"{name}-{frame_count - 1}",
                    "nbr_samples": frame_count,
                }
            )
            self.tables["scene"][scene_token] = self.scene[-1]
            for i in range(frame_count):
                token = f"{name}-{i}"
                pose_token = token + "-pose"
                self.tables["ego_pose"][pose_token] = {
                    "token": pose_token,
                    "translation": [i * 2.0, 0.0, 0.0],
                    "rotation": [1.0, 0.0, 0.0, 0.0],
                }
                data = {}
                for sensor in SensorType:
                    data[sensor.name] = st = f"{token}-{sensor.name}"
                    self.tables["sample_data"][st] = {
                        "token": st,
                        "calibrated_sensor_token": sensor.name,
                        "ego_pose_token": pose_token,
                        "filename": f"absent/{st}",
                        "height": 900,
                        "width": 1600,
                    }
                    self.tables["calibrated_sensor"][sensor.name] = {
                        "translation": [0.0, 0.0, 0.0],
                        "rotation": [1.0, 0.0, 0.0, 0.0],
                        "camera_intrinsic": []
                        if sensor == SensorType.LIDAR_TOP
                        else [
                            [1000.0, 0.0, 800.0],
                            [0.0, 1000.0, 450.0],
                            [0.0, 0.0, 1.0],
                        ],
                    }
                annotations = []
                for actor, category, xyz, velocity in (
                    ("car", "vehicle.car", [i * 2.0 + 6.0, 0.0, 0.0], [4.0, 0.0, 0.0]),
                    (
                        "ped1",
                        "human.pedestrian.adult",
                        [i * 0.6, 3.0, 0.0],
                        [1.2, 0.0, 0.0],
                    ),
                    (
                        "ped2",
                        "human.pedestrian.adult",
                        [i * 0.6, 3.5, 0.0],
                        [1.2, 0.0, 0.0],
                    ),
                ):
                    annotation = f"{token}-{actor}-annotation"
                    annotations.append(annotation)
                    self.tables["sample_annotation"][annotation] = {
                        "token": annotation,
                        "instance_token": f"{name}-{actor}",
                        "category_name": category,
                        "visibility_token": "4",
                        "translation": xyz,
                        "velocity": velocity,
                    }
                self.tables["sample"][token] = {
                    "token": token,
                    "scene_token": scene_token,
                    "timestamp": 1_000_000 + i * 500_000,
                    "prev": f"{name}-{i - 1}" if i else "",
                    "next": f"{name}-{i + 1}" if i + 1 < frame_count else "",
                    "data": data,
                    "anns": annotations,
                }

    def get(self, table, token):
        return self.tables[table][token]

    def get_box(self, token):
        return SimpleNamespace(
            token=token,
            center=self.get("sample_annotation", token)["translation"],
            orientation=[1.0, 0.0, 0.0, 0.0],
            wlh=[1.0, 2.0, 1.5],
        )

    def box_velocity(self, token):
        return self.get("sample_annotation", token)["velocity"]


def write_devkit_fixture(root):
    """Write synthetic tables/maps readable by the real nuScenes devkit, without mocks."""
    from nuscenes.map_expansion.map_api import locations
    from PIL import Image

    root = Path(root)
    (root / "v1.0-mini").mkdir(parents=True)
    (root / "maps" / "expansion").mkdir(parents=True)
    Image.new("L", (2, 2), 255).save(root / "maps" / "mask.png")
    nusc = SyntheticNuScenes()
    tables = nusc.tables
    tables["attribute"] = {}
    tables["category"] = {
        name: {"token": name, "name": name}
        for name in ("vehicle.car", "human.pedestrian.adult")
    }
    tables["sensor"] = {
        s.name: {
            "token": s.name,
            "channel": s.name,
            "modality": "lidar" if s == SensorType.LIDAR_TOP else "camera",
        }
        for s in SensorType
    }
    tables["instance"] = {}
    tables["map"] = {
        "map": {"token": "map", "filename": "maps/mask.png", "log_tokens": ["log"]}
    }
    for token, record in tables["calibrated_sensor"].items():
        record.update(token=token, sensor_token=token)
    for token, record in tables["log"].items():
        record["token"] = token
    for token, record in tables["visibility"].items():
        record["token"] = token
    for sample in tables["sample"].values():
        for sensor_name, token in sample["data"].items():
            tables["sample_data"][token].update(
                sample_token=sample["token"],
                is_key_frame=True,
                timestamp=sample["timestamp"],
                prev=sample["prev"] + "-" + sensor_name if sample["prev"] else "",
                next=sample["next"] + "-" + sensor_name if sample["next"] else "",
            )
        for token in sample["anns"]:
            annotation = tables["sample_annotation"][token]
            actor = annotation["instance_token"].rsplit("-", 1)[1]
            annotation.update(
                sample_token=sample["token"],
                rotation=[1.0, 0.0, 0.0, 0.0],
                size=[1.0, 2.0, 1.5],
                prev=f"{sample['prev']}-{actor}-annotation" if sample["prev"] else "",
                next=f"{sample['next']}-{actor}-annotation" if sample["next"] else "",
            )
            tables["instance"][annotation["instance_token"]] = {
                "token": annotation["instance_token"],
                "category_token": annotation["category_name"],
            }
    for table, records in tables.items():
        (root / "v1.0-mini" / f"{table}.json").write_text(
            json.dumps(list(records.values())), encoding="utf-8"
        )

    for location in locations:
        layers = {
            name: []
            for name in (
                "polygon",
                "line",
                "node",
                "drivable_area",
                "road_segment",
                "road_block",
                "lane",
                "ped_crossing",
                "walkway",
                "stop_line",
                "carpark_area",
                "road_divider",
                "lane_divider",
                "traffic_light",
                "lane_connector",
            )
        }
        layers.update(
            version="1.3",
            canvas_edge=[100.0, 100.0],
            arcline_path_3={},
            connectivity={},
        )
        for name, y1, y2 in (
            ("lane", -2.0, 2.0),
            ("ped_crossing", 2.0, 4.0),
            ("walkway", 2.0, 4.0),
            ("drivable_area", -5.0, 5.0),
        ):
            prefix = f"{location}-{name}"
            nodes = []
            for i, (x, y) in enumerate(
                ((-20.0, y1), (100.0, y1), (100.0, y2), (-20.0, y2))
            ):
                token = f"{prefix}-node{i}"
                nodes.append(token)
                layers["node"].append({"token": token, "x": x, "y": y})
            polygon = prefix + "-polygon"
            layers["polygon"].append(
                {"token": polygon, "exterior_node_tokens": nodes, "holes": []}
            )
            if name == "drivable_area":
                layers[name].append({"token": prefix, "polygon_tokens": [polygon]})
            else:
                record = {"token": prefix, "polygon_token": polygon}
                if name == "lane":
                    record.update(
                        left_lane_divider_segments=[], right_lane_divider_segments=[]
                    )
                layers[name].append(record)
        (root / "maps" / "expansion" / f"{location}.json").write_text(
            json.dumps(layers), encoding="utf-8"
        )

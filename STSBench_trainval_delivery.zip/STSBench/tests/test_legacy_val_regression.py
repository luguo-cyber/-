"""Optional read-only regression against upstream code and its bundled Val database."""

import hashlib
from pathlib import Path
import subprocess
from types import ModuleType

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from annotator.data.models import Scene
from annotator.data.maneuvers import ManeuverType as M
from annotator.data.pipeline import open_database
import mine_maneuvers as adapted

ROOT = Path(__file__).resolve().parents[1]
BASELINE = "38c5174d793f369b456ba27192b8384261562c0a"


def signature(events):
    return [
        (
            tuple(p.type.value for p in e.pos_maneuvers),
            tuple(n.type.value for n in e.neg_maneuvers),
            tuple(f.id for f in e.frames),
            tuple(a.id for a in e.other_agents),
            e.is_ego,
            e.is_agent,
            e.instance_token,
        )
        for e in events
    ]


def test_upstream_val_event_assembly_on_three_real_scenes():
    path = ROOT / "nuScenes.db"
    if not path.exists() or not (ROOT / ".git").exists():
        pytest.skip("Optional check requires upstream Git history and bundled Val DB")
    source = subprocess.check_output(
        ["git", "show", f"{BASELINE}:mine_maneuvers.py"], cwd=ROOT
    )
    baseline = ModuleType("upstream_reference_miner")
    exec(compile(source, "upstream_reference_miner.py", "exec"), baseline.__dict__)
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    single = [
        M.ACCELERATE,
        M.DECELERATE,
        M.STOP,
        M.LEFT_TURN,
        M.RIGHT_TURN,
        M.U_TURN,
        M.REVERSE,
        M.LANE_CHANGE,
    ]
    pair = [
        M.OVERTAKE_AGENT,
        M.WAIT_PED_CROSS,
        M.FOLLOW_AGENT,
        M.LEAD_AGENT,
        M.PASS_AGENT,
        M.STATIONARY_BEHIND_AGENT,
        M.STATIONARY_IN_FRONT_OF_AGENT,
        M.STATIONARY_LEFT_OF_AGENT,
        M.STATIONARY_RIGHT_OF_AGENT,
        M.MOVING_RIGHT_OF_AGENT,
        M.MOVING_LEFT_OF_AGENT,
    ]
    engine = open_database(path, readonly=True)
    try:
        with Session(engine) as session, session.no_autoflush:
            scenes = session.scalars(select(Scene).order_by(Scene.name).limit(3)).all()
            assert [s.name for s in scenes] == [
                "scene-0003",
                "scene-0012",
                "scene-0013",
            ]
            for scene in scenes:
                for kind in single:
                    assert signature(
                        adapted.mine_ego_maneuver(scene.frames, kind)
                    ) == signature(baseline.mine_ego_maneuver(scene.frames, kind))
                for kind in pair:
                    assert signature(
                        adapted.mine_ego_agent_maneuver(scene, session, kind)
                    ) == signature(
                        baseline.mine_ego_agent_maneuver(scene, session, kind)
                    )
                tracks = sorted(scene.tracks, key=lambda t: t.id)
                # One vehicle and one pedestrian track where present.
                chosen = [
                    next(
                        (
                            t
                            for t in tracks
                            if t.agents and t.agents[0].is_human == human
                        ),
                        None,
                    )
                    for human in (False, True)
                ]
                for track in filter(None, chosen):
                    for kind in single + [M.CROSS, M.JAYWALK, M.RUN, M.WALK, M.STAND]:
                        assert signature(
                            adapted.mine_agent_maneuver(track, kind)
                        ) == signature(baseline.mine_agent_maneuver(track, kind))
                    for kind in pair + [M.WALK_ALONGSIDE, M.WALK_OPPOSITE]:
                        assert signature(
                            adapted.mine_agent_agent_maneuver(track, session, kind)
                        ) == signature(
                            baseline.mine_agent_agent_maneuver(track, session, kind)
                        )
                    for kind in [m for m in M if m.name.endswith("_EGO")]:
                        assert signature(
                            adapted.mine_agent_ego_maneuver(track, kind)
                        ) == signature(baseline.mine_agent_ego_maneuver(track, kind))
    finally:
        engine.dispose()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == before

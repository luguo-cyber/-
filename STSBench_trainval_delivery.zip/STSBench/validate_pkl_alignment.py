"""Read-only alignment of exported labels with trusted DiffusionDrive info PKLs."""

import argparse
from collections import Counter
import json
from pathlib import Path
import pickle


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def load_labels(path):
    with Path(path).open(encoding="utf-8") as stream:
        data = json.load(stream, object_pairs_hook=unique_object)
    if data.get("schema_version") != 1 or not isinstance(data.get("samples"), dict):
        raise ValueError("Expected schema_version=1 sample-label JSON")
    taxonomy = set(data["taxonomy"])
    for token, row in data["samples"].items():
        if not token or not isinstance(row.get("labels"), list):
            raise ValueError(f"Invalid sample record: {token}")
        if (
            len(row["labels"]) != len(set(row["labels"]))
            or set(row["labels"]) - taxonomy
        ):
            raise ValueError(f"Duplicate/unknown labels for {token}")
        if row.get("split") not in ("train", "val", "mini_train", "mini_val"):
            raise ValueError(f"Invalid official split for {token}")
    return data


def load_infos(path):
    with Path(path).open("rb") as stream:
        data = pickle.load(stream)  # Only load trusted company-generated PKLs.
    if isinstance(data, dict):
        keys = [key for key in ("infos", "data_list") if key in data]
        if len(keys) != 1:
            raise ValueError("Expected exactly one of 'infos' or 'data_list' in PKL")
        data = data[keys[0]]
    if not isinstance(data, (list, tuple)):
        raise ValueError("Expected a list/tuple of sample info dictionaries")
    return data


def split_names(split):
    if split == "trainval":
        return {"train", "val"}
    if split == "mini_trainval":
        return {"mini_train", "mini_val"}
    if split in ("train", "val", "mini_train", "mini_val"):
        return {split}
    raise ValueError(f"Unsupported expected split: {split}")


def validate_infos(infos, data, expected_split, require_full_split=False):
    samples, taxonomy = data["samples"], sorted(data["taxonomy"])
    allowed_splits = split_names(expected_split)
    expected_tokens = {
        t for t, row in samples.items() if row["split"] in allowed_splits
    }
    counts, invalid, mismatch, split_mismatch = Counter(), [], [], []
    matched_rows = 0
    for i, info in enumerate(infos):
        if not isinstance(info, dict):
            invalid.append({"row": i, "reason": "not a dict"})
            continue
        candidates = [info[k] for k in ("token", "sample_token") if k in info]
        if (
            not candidates
            or any(not isinstance(t, str) or not t for t in candidates)
            or len(set(candidates)) != 1
        ):
            invalid.append(
                {"row": i, "reason": "missing/invalid/conflicting token fields"}
            )
            continue
        token = candidates[0]
        counts[token] += 1
        if token not in samples:
            continue
        matched_rows += 1
        row = samples[token]
        if row["split"] not in allowed_splits:
            split_mismatch.append(token)
        for field in ("scene_token", "timestamp"):
            if field in info and info[field] != row[field]:
                mismatch.append({"sample_token": token, "field": field, "row": i})
    tokens = set(counts)
    matched = tokens & samples.keys()
    missing = tokens - samples.keys()
    not_in_pkl = expected_tokens - tokens
    labeled = {t for t in matched if samples[t]["labels"]}
    class_counts = Counter(label for t in matched for label in samples[t]["labels"])
    duplicates = {t: c for t, c in sorted(counts.items()) if c > 1}
    issues = []
    for failed, message in (
        (not infos, "empty_pkl"),
        (not expected_tokens, "no_labels_for_expected_split"),
        (bool(invalid), "invalid_info_rows"),
        (bool(duplicates), "duplicate_pkl_tokens"),
        (bool(missing), "pkl_tokens_missing_from_labels"),
        (bool(split_mismatch), "official_split_mismatch"),
        (bool(mismatch), "sample_metadata_mismatch"),
        (require_full_split and bool(not_in_pkl), "expected_split_not_fully_in_pkl"),
    ):
        if failed:
            issues.append(message)
    return {
        "expected_split": expected_split,
        "ok": not issues,
        "issues": issues,
        "pkl_row_count": len(infos),
        "pkl_unique_sample_count": len(tokens),
        "matched_row_count": matched_rows,
        "matched_unique_sample_count": len(matched),
        "sample_match_rate": matched_rows / len(infos) if infos else 0.0,
        "unique_sample_match_rate": len(matched) / len(tokens) if tokens else 0.0,
        "labeled_matched_sample_count": len(labeled),
        "unlabeled_matched_sample_count": len(matched) - len(labeled),
        "label_coverage_among_matched_samples": len(labeled) / len(matched)
        if matched
        else 0.0,
        "label_coverage_among_pkl_unique_samples": len(labeled) / len(tokens)
        if tokens
        else 0.0,
        "expected_split_label_sample_count": len(expected_tokens),
        "expected_split_samples_absent_from_pkl_count": len(not_in_pkl),
        "expected_split_samples_absent_from_pkl_examples": sorted(not_in_pkl)[:20],
        "missing_label_token_count": len(missing),
        "missing_label_tokens": sorted(missing),
        "duplicate_pkl_tokens": duplicates,
        "invalid_row_count": len(invalid),
        "invalid_row_examples": invalid[:20],
        "official_split_mismatch_tokens": sorted(set(split_mismatch)),
        "metadata_mismatch_count": len(mismatch),
        "metadata_mismatch_examples": mismatch[:20],
        "class_sample_counts": {name: class_counts[name] for name in taxonomy},
        "ego_class_sample_counts": {
            name: sum(name in samples[t]["ego_labels"] for t in matched)
            for name in taxonomy
        },
        "agent_class_sample_counts": {
            name: sum(name in samples[t]["agent_labels"] for t in matched)
            for name in taxonomy
        },
    }, tokens


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument(
        "--pkl",
        action="append",
        required=True,
        metavar="SPLIT=PATH",
        help="Repeat for each PKL; SPLIT is the expected official split",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--require-full-split",
        action="store_true",
        help="Also fail if exported samples in the expected split are absent from PKL",
    )
    args = parser.parse_args()
    if args.output.exists() or args.output.suffix.lower() != ".json":
        parser.error(
            "Output must be a new .json file; existing files are never overwritten"
        )
    data = load_labels(args.labels)
    reports, token_sets = [], []
    for specification in args.pkl:
        split, sep, filename = specification.partition("=")
        if not sep:
            parser.error(
                "Use --pkl train=/path/to/infos.pkl (or val/trainval/mini_train/mini_val)"
            )
        split_names(split)
        path = Path(filename).expanduser().resolve(strict=True)
        report, tokens = validate_infos(
            load_infos(path), data, split, args.require_full_split
        )
        report["path"] = str(path)
        reports.append(report)
        token_sets.append(tokens)
    overlaps = []
    for i in range(len(reports)):
        for j in range(i + 1, len(reports)):
            overlap = token_sets[i] & token_sets[j]
            disjoint = not (
                split_names(reports[i]["expected_split"])
                & split_names(reports[j]["expected_split"])
            )
            overlaps.append(
                {
                    "pkl_indices": [i, j],
                    "sample_overlap_count": len(overlap),
                    "unexpected_split_overlap": bool(overlap) and disjoint,
                    "sample_overlap_examples": sorted(overlap)[:20],
                }
            )
    ok = all(r["ok"] for r in reports) and not any(
        r["unexpected_split_overlap"] for r in overlaps
    )
    result = {
        "ok": ok,
        "labels_path": str(args.labels.resolve()),
        "labels_summary": data.get("summary"),
        "files": reports,
        "pairwise_overlaps": overlaps,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    for report in reports:
        print(
            f"{report['path']}: match={report['sample_match_rate']:.2%}, "
            f"label coverage={report['label_coverage_among_matched_samples']:.2%}, "
            f"issues={report['issues']}"
        )
    raise SystemExit(0 if ok else 2)


if __name__ == "__main__":
    main()
